from pysendgmaillib import gmailsender, GMailSenderServer
del pysendgmaillib
